public class Problem24 
{



    private enum State {NEW_ROLL, KEEP_ROLLING} 
  
  State currentState = State.NEW_ROLL;
   
   public static int MethodWouldBe() {
      
      
      
      switch(currentState) {
      
         case NEW_ROLL:
            // code for new roll
            break;
         
         case KEEP_ROLLING:
            // code for keep rolling           
            break;
      
      }
   
   
   
   
   }


}