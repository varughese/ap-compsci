/**
 * Model-View-Controller example:
 * implements "text" controller in the MVC sphere demo.
 */

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class TextController
    implements ActionListener
{
  private Sphere model;

  public TextController(Sphere sphere)
  {
    model = sphere;
  }

  public void actionPerformed(ActionEvent e)
  {
    JTextField t = (JTextField)e.getSource();
    try
    {
      double r = Double.parseDouble(t.getText());
      model.setRadius(r);
    }
    catch (NumberFormatException ex)
    {
    }
    finally
    {
      t.setText(String.format(" %.1f", model.getRadius()));
    }
  }
}
