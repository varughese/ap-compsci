/**
 * Model-View-Controller example:
 * implements "graphics" controller in the MVC sphere demo.
 */

import java.awt.Point;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseEvent;

public class GraphicsController
    implements MouseListener, MouseMotionListener
{
  private GraphicsView view;
  private Sphere model;

  private boolean picked;
  private int anchorR, startR;

  public GraphicsController(Sphere sphere)
  {
    model = sphere;
  }

  public void setMousePanel(GraphicsView v)
  {
    view = v;
  }

  private double getDistance(int x, int y)
  {
    int x0 = (int)model.getX();
    int y0 = (int)model.getY();
    return Point.distance(x, y, x0, y0);
  }

  private boolean isOnBorder(int x, int y)
  {
    double r = model.getRadius();
    double d = getDistance(x, y);
    return d >= r * .9 && d <= r * 1.1;
  }

  public void mousePressed(MouseEvent e)
  {
    int x = e.getX() - view.getWidth() / 2;
    int y = e.getY() - view.getHeight() / 2;

    if (isOnBorder(x, y))
    {
      picked = true;
      anchorR = (int)getDistance(x, y);
      startR = (int)model.getRadius();
      view.update(model, null);
    }
  }

  public void mouseReleased(MouseEvent e)
  {
    picked = false;
  }

  public void mouseDragged(MouseEvent e)
  {
    if (!picked)
      return;

    int x = e.getX() - view.getWidth() / 2;
    int y = e.getY() - view.getHeight() / 2;
    double r = getDistance(x, y);
    model.setRadius(r - anchorR + startR);
  }

  // Not used:
  public void mouseEntered(MouseEvent e) {}
  public void mouseExited(MouseEvent e) {}
  public void mouseClicked(MouseEvent e) {}
  public void mouseMoved(MouseEvent e) {}
}
