/**
 * Model-View-Controller example:
 * Implements a Sphere model with methods volume and surfaceArea.
 */
 
import java.util.Observable;

class Sphere extends Observable
{
  private double radius;
  private double xCenter;
  private double yCenter;

  // Constructs a sphere with given coordinates of the center and radius.
  Sphere (double x, double y, double r)
  {
    xCenter = x;
    yCenter = y;
    radius = r;
  }

  // Returns the radius of this sphere.
  public double getRadius()
  {
    return radius;
  }

  // Returns the x-coordinate of the center.
  public double getX()
  {
    return xCenter;
  }

  // Returns the y-coordinate of the center.
  public double getY()
  {
    return yCenter;
  }

  // Sets the radius of this sphere.
  public void setRadius(double r)
  {
    radius = r;
    setChanged();
    notifyObservers();
  }

  // Moves this sphere to (x, y).
  public void move(double x, double y)
  {
    xCenter = x;
    yCenter = y;
    setChanged();
    notifyObservers();
  }

  // Returns the volume of this sphere.
  public double volume()
  {
    return 4.0 / 3.0 * Math.PI * radius * radius * radius;
  }

  // Returns the surfaceArea of this sphere.
  public double surfaceArea()
  {
    return 4.0 * Math.PI * radius * radius;
  }

  // Returns a string representation of this sphere.
  public String toString()
  {
    return "Sphere [Center = (" + xCenter + ", " + yCenter + ") Radius = " + radius + "]";
  }
}
